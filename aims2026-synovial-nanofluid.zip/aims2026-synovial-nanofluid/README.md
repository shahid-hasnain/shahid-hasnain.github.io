# Gold-nanoparticle synovial flow solver

Companion code for

> B. S. Alshammari, S. Hasnain, M. Saqib, *Heat and mass transfer in gold
> nanoparticle-enhanced synovial fluid for biomedical applications: a
> Carreau–Yasuda study*, **AIMS Mathematics** 11(7) (2026) 22543–22575.
> https://doi.org/10.3934/math.2026911

A finite-volume solver for flow, heat, nanoparticle concentration and induced
magnetic field of synovial fluid in a wavy, porous annular channel of the knee
joint. The viscosity is a temperature- and concentration-dependent
Carreau–Yasuda law (Model I, with Models II and III as benchmarks), and the
outer wall carries a second-order slip condition.

Every step in `solver.py` quotes the article equation or boundary condition
it implements, Eqs. (3.7)–(3.17), so you can follow the mathematics line by
line.

## Files

| File | What it does |
|---|---|
| `solver.py` | The solver. Run it for a quick check of all three viscosity models at the mid-period station. |
| `temperature_results.py` | Draws the **Temperature Results** contour over one wave period. |

## How to run

```
pip install -r requirements.txt
python solver.py                  # under 1 s
python temperature_results.py     # about 5 s
```

Expected output of `python solver.py` (z = 0.5, N = 161): Model I gives
dp/dz ≈ −16.26 with the flow rate held at q = 2 to ten digits; the Picard
iteration converges in about 55 sweeps.

## How the pressure gradient is found

With the viscosity, temperature, concentration and induced field frozen
inside one iteration, the momentum equation (3.9) is linear in the velocity
and dp/dz. So the velocity is split as `w = w0 + G w1`:

1. `w0` solves (3.9) with dp/dz = 0 and the full slip condition (3.17);
2. `w1` solves (3.9) with dp/dz = 1 and the homogeneous slip condition;
3. `G = (q − q[w0]) / q[w1]` fixes the flow rate exactly.

At convergence the superposition is exact for all three viscosity models.

## Note on this version

This is a corrected version of the code used while preparing the article:
the radial grid follows the wavy wall R₂(z), the source terms follow the
signs of Eqs. (3.9)–(3.10), and dp/dz comes from the exact superposition
above. Numbers therefore differ in detail from the published figures.

The Temperature Results figure is an **illustrative demonstration** of the
solver. It is **not** a figure from the published article.

## Collaboration

I welcome collaboration on extensions of this model: new rheology, other
joint geometries, time-dependent loading, experimental comparison, or
student projects built on this code. If you use the code, find a problem,
or would like to work together, please write to me:

Shahid Hasnain — shahid.hasnain@uoc.edu.pk · s.hasnain.mathematics@gmail.com

## Licence

MIT (see `LICENSE`). If you use this code, please cite the article above.
