"""
=============================================================================
Temperature Results: temperature field theta(z, r) over one wave period of
the wavy synovial channel, Model I (Carreau-Yasuda), baseline parameters.

ILLUSTRATIVE DEMONSTRATION - this figure shows what the solver can do.
It is NOT a figure from the published article.

At each of nz axial stations the solver (solver.py) computes all fields on
the true gap eps <= r <= R2(z) with the flow rate fixed at q = 2, and the
temperature is drawn on those curvilinear grids.

Usage
    python temperature_results.py               # nz = 41 stations, N = 161
    python temperature_results.py --nz 81       # smoother contour
    python temperature_results.py --model 2     # benchmark Model II

Output
    temperature_results.png

Requires: numpy, scipy, matplotlib, and solver.py in the same folder.
=============================================================================
"""

import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import solver as S

MODEL_NAMES = {1: "Model I", 2: "Model II", 3: "Model III"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nz", type=int, default=41, help="axial stations")
    ap.add_argument("--N", type=int, default=161, help="radial nodes")
    ap.add_argument("--model", type=int, default=1, choices=[1, 2, 3])
    ap.add_argument("--out", default="temperature_results.png")
    args = ap.parse_args()

    p = S.Params()
    p.N = args.N
    p.model = args.model
    zs, F = S.solve_channel(p, nz=args.nz)
    Z = np.repeat(zs[None, :], p.N, axis=0)
    R, T = F["R"], F["T"]

    fig, ax = plt.subplots(figsize=(11, 5.0))
    levels = np.linspace(T.min(), T.max(), 31)
    cf = ax.contourf(Z, R, T, levels=levels, cmap="coolwarm")
    ax.contour(Z, R, T, levels=levels[::3], colors="k",
               linewidths=0.35, alpha=0.55)
    zf = np.linspace(0, 1, 400)
    ax.plot(zf, S.R2(zf, p), color="k", lw=2.0)            # wavy outer wall
    ax.plot(zf, np.full_like(zf, p.eps), color="k", lw=2.0)  # inner wall
    ax.set_xlim(0, 1)
    ax.set_xlabel("Dimensionless axial coordinate $z$", fontsize=11)
    ax.set_ylabel("Dimensionless radius $r$", fontsize=11)
    cb = fig.colorbar(cf, ax=ax, pad=0.02)
    cb.set_label(r"Temperature $\theta$", fontsize=11)
    ax.set_title(f"Temperature Results: wavy synovial channel "
                 f"({MODEL_NAMES[p.model]}, baseline parameters)",
                 fontsize=12, fontweight="bold", pad=26)
    ax.text(0.5, 1.02, "Illustrative demonstration - not a figure from the "
            "published article", transform=ax.transAxes, ha="center",
            va="bottom", fontsize=9, style="italic",
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#999"))
    fig.tight_layout()
    fig.savefig(args.out, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    print(f"{MODEL_NAMES[p.model]}, nz = {args.nz}, N = {p.N}")
    print(f"  theta range       : [{T.min():.4f}, {T.max():.4f}]")
    print(f"  dp/dz over z      : [{F['dpdz'].min():+.4f}, {F['dpdz'].max():+.4f}]")
    print(f"saved {args.out}")


if __name__ == "__main__":
    main()
