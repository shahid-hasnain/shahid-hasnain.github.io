"""
=============================================================================
Gold-nanoparticle synovial flow solver
Companion code for:
    B. S. Alshammari, S. Hasnain, M. Saqib,
    "Heat and mass transfer in gold nanoparticle-enhanced synovial fluid for
    biomedical applications: a Carreau-Yasuda study",
    AIMS Mathematics 11(7) (2026) 22543-22575.
    https://doi.org/10.3934/math.2026911

Flow, heat, nanoparticle concentration and induced magnetic field of
synovial fluid in a wavy, porous annular channel  eps <= r <= R2(z),
in the wave frame, long-wavelength and low-Reynolds-number limit.
Every equation below carries the number it has in the article.

  Outer wall      R2(z) = 1 + eps1 cos(alpha1 pi z) + eps2 cos(alpha2 pi z)

  (3.7)  dh_r/dr + h_r/r = 0  with h_r(eps) = 0   =>   h_r = 0 everywhere
  (3.8)  dp/dr = 0            =>   p = p(z), dp/dz is one number per z
  (3.9)  dp/dz = 2[ (mu/r) d/dr(r w') + mu' w' ] - k mu w
                 + (S^2 / (2 Re)) h_z' (R2/r + h_r) - Gr theta + Gf phi
         Note 2[(mu/r)(r w')' + mu' w'] = (2/r) d/dr( r mu w' ),
         which is the conservative form discretised here.
  (3.10) theta'' + theta'/r + Nb phi' theta' + Nt theta'^2
                 + Ec Pr mu w'^2 + Q = 0
  (3.11) phi'' + phi'/r + (Nt/Nb)(theta'' + theta'/r) - gamma phi + S0 = 0
  (3.12) (R2/r + h_r) w' = -(1/Rm) (1/r) d/dr( r h_z' )
  (3.13) Model I   Carreau-Yasuda, temperature- and concentration-dependent
  (3.14) Model II  (1 + alpha phi) [1 + n omega_e^2 w'^2]
  (3.15) Model III 1 + (alpha phi / 2) omega_e^2 w'^2
  (3.16) inner wall r = eps:  w = 0, h_z = 0, theta = 0, phi = 0
  (3.17) outer wall r = R2:   w = 1 - beta w' - xi w''   (second-order slip),
                              h_z = 0, theta = 1, phi = 1

  Flow rate       q = 2 pi int_eps^R2 w r dr, held fixed (q = 2 in the article)

Pressure gradient by DIRECT SUPERPOSITION at fixed flow rate
  With mu, theta, phi and h_z frozen inside one Picard sweep, Eq. (3.9) is
  LINEAR in (w, dp/dz). Hence w = w0 + G w1, where
     w0 : solves (3.9) with dp/dz = 0 and the full slip condition (3.17);
     w1 : solves (3.9) with dp/dz = 1, no buoyancy/magnetic forcing and the
          homogeneous slip condition w + beta w' + xi w'' = 0;
  and G = (q - q[w0]) / q[w1] makes q[w] equal the target exactly.
  The Picard loop then updates mu, theta, phi, h_z. At convergence the
  superposition is exact for every viscosity model (also shear-dependent).

Numerics
  Finite volumes on a uniform radial grid that spans the true gap
  [eps, R2(z)] at each station; face fluxes  r_f mu_f / dr,  volumetric terms
  times r_i dr; second-order one-sided stencils for the slip row; damped
  Picard iteration for the couplings; sparse direct solves.

Corrections relative to the working code used while preparing the article
  * the radial grid follows the wavy wall R2(z) (it was fixed at [0.2, 1.6]);
  * the signs of the heat sources follow Eq. (3.10), and those of the
    buoyancy and magnetic terms follow Eq. (3.9);
  * dp/dz from the exact superposition above (no empirical h^3 rescaling).
  Results therefore differ in detail from the published figures.

Requires: numpy (>= 1.25), scipy.      Licence: MIT (see LICENSE).

Questions, corrections and collaboration are welcome:
    Shahid Hasnain, shahid.hasnain@uoc.edu.pk, s.hasnain.mathematics@gmail.com
=============================================================================
"""

import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve


# =============================================================== parameters
class Params:
    """Baseline values of the article (Section 5 and figure captions)."""

    def __init__(self):
        # ---- geometry
        self.eps = 0.2          # inner radius
        self.eps1 = 0.2         # outer wall amplitudes and wave numbers
        self.eps2 = 0.1
        self.alpha1 = 3.0
        self.alpha2 = 2.0

        # ---- flow
        self.k = 0.01           # porous parameter
        self.Gr = 3.0           # thermal Grashof number
        self.Gf = 5.0           # concentration Grashof number
        self.Re = 0.1           # Reynolds number
        self.S = 2.5            # Strommer number
        self.Rm = 3.0           # magnetic Reynolds number
        self.beta = 0.1         # first-order slip
        self.xi = 0.005         # second-order slip
        self.q = 2.0            # prescribed flow rate

        # ---- heat and mass
        self.Pr = 0.7
        self.Ec = 0.9
        self.Nb = 3.1
        self.Nt = 0.1
        self.Q = 2.0            # heat source
        self.gamma = 0.5        # absorption coefficient
        self.S0 = 0.0           # constant source in (3.11), not set in the article

        # ---- viscosity
        self.model = 1
        self.m_infty = 0.01
        self.beta1 = 0.05
        self.beta2 = 0.01
        self.beta3 = 0.5
        self.A1 = 0.01
        self.A2 = 0.1
        self.n0 = 0.4
        self.a = 2.0
        self.omega_i = 0.09
        self.n = -0.2
        self.omega_e = 0.01
        self.alpha = 0.5

        # ---- numerics
        self.N = 161            # radial nodes (as in the article)
        self.tol = 1e-10
        self.max_iter = 3000
        self.relax = 0.5        # fraction of the NEW iterate taken


# ================================================================= geometry
def R2(z, p):
    """Outer wall, dimensionless form of Eq. (2.1)."""
    return 1 + p.eps1 * np.cos(p.alpha1 * np.pi * z) \
             + p.eps2 * np.cos(p.alpha2 * np.pi * z)


# ================================================================ viscosity
def viscosity(wr, theta, phi, p):
    """Eqs. (3.13)-(3.15); shear rate |gamma_dot| = |dw/dr|."""
    g = np.abs(wr)
    if p.model == 1:                                       # (3.13)
        mu_inf = p.m_infty * np.exp(-p.beta2 * theta)
        mu_0 = (1 + p.A1 * phi) * np.exp(-p.beta1 * theta)
        n_eff = p.n0 * (1 + p.A2 * phi) * np.exp(-p.beta3 * theta)
        mu = mu_inf + (mu_0 - mu_inf) * (1 + (p.omega_i * g) ** p.a) \
            ** ((n_eff - 1) / p.a)
    elif p.model == 2:                                     # (3.14)
        mu = (1 + p.alpha * phi) * (1 + p.n * p.omega_e**2 * g**2)
    else:                                                  # (3.15)
        mu = 1 + (p.alpha * phi / 2) * p.omega_e**2 * g**2
    return np.maximum(mu, 1e-6)


# ========================================================== FV operators
def diffusion_rows(r, coef):
    """Rows of  -[r coef f']_w^e  at interior nodes: lower, main, upper."""
    dr = r[1] - r[0]
    cf = 0.5 * (coef[:-1] + coef[1:])                     # face coefficients
    rf = 0.5 * (r[:-1] + r[1:])                           # face radii
    af = cf * rf / dr                                     # face conductances
    lo = np.zeros(len(r) - 1); up = np.zeros(len(r) - 1)
    md = np.zeros(len(r))
    lo[:-1] = -af[:-1]          # lo[i-1] multiplies f[i-1] in row i
    up[1:] = -af[1:]            # up[i]   multiplies f[i+1] in row i
    md[1:-1] = af[:-1] + af[1:]
    return lo, md, up


def solve_dirichlet(r, coef, sink, rhs_vol, f_left, f_right):
    """-(r coef f')' + sink r f = rhs r  (cell-integrated), Dirichlet ends."""
    dr = r[1] - r[0]
    lo, md, up = diffusion_rows(r, coef)
    md[1:-1] += sink[1:-1] * r[1:-1] * dr
    rhs = rhs_vol * r * dr
    md[0] = 1.0; up[0] = 0.0; rhs[0] = f_left
    md[-1] = 1.0; lo[-1] = 0.0; rhs[-1] = f_right
    A = diags([lo, md, up], [-1, 0, 1], format="csc")
    return spsolve(A, rhs)


def solve_momentum(r, mu, forcing, slip_rhs, p):
    """(2/r)(r mu w')' - k mu w = forcing,  i.e. Eq. (3.9) rearranged.

    Inner wall: w = 0 (3.16). Outer wall: w + beta w' + xi w'' = slip_rhs
    (3.17) with second-order one-sided stencils:
        w'  ~ ( 3 wN - 4 wN-1 +   wN-2          ) / (2 dr)
        w'' ~ ( 2 wN - 5 wN-1 + 4 wN-2 -  wN-3  ) / dr^2
    """
    N = len(r)
    dr = r[1] - r[0]
    lo, md, up = diffusion_rows(r, 2.0 * mu)
    md[1:-1] += p.k * mu[1:-1] * r[1:-1] * dr
    rhs = -forcing * r * dr
    md[0] = 1.0; up[0] = 0.0; rhs[0] = 0.0
    b = p.beta / dr
    x = p.xi / dr**2
    md[-1] = 1.0 + 1.5 * b + 2.0 * x
    lo[-1] = -(2.0 * b + 5.0 * x)
    lo2 = np.zeros(N - 2); lo2[-1] = 0.5 * b + 4.0 * x
    lo3 = np.zeros(N - 3); lo3[-1] = -x
    rhs[-1] = slip_rhs
    A = diags([md, up, lo, lo2, lo3], [0, 1, -1, -2, -3], format="csc")
    return spsolve(A, rhs)


def flow_rate(r, w):
    """q = 2 pi int w r dr."""
    return 2 * np.pi * np.trapezoid(w * r, r)


# ======================================================== station solver
def solve_station(z, p, return_info=False):
    """All fields at axial station z, with q[w] = p.q exactly.

    Returns a dict with r, w, theta, phi, hz, mu and dp/dz.
    """
    R = R2(z, p)
    r = np.linspace(p.eps, R, p.N)
    s = (r - p.eps) / (R - p.eps)

    # initial guess: profiles that satisfy the wall values
    w = 1.0 * s
    theta = s.copy()
    phi = s.copy()
    hz = np.zeros(p.N)
    one = np.ones(p.N)
    zero = np.zeros(p.N)
    mag = p.S**2 / (2 * p.Re)
    G = 0.0
    res = np.inf

    for it in range(p.max_iter):
        w_old, th_old, ph_old, hz_old = w.copy(), theta.copy(), phi.copy(), hz.copy()

        # ---- viscosity (3.13)-(3.15)
        wr = np.gradient(w, r, edge_order=2)
        mu = viscosity(wr, theta, phi, p)

        # ---- momentum (3.9) by direct superposition at fixed q
        #   (2/r)(r mu w')' - k mu w = dp/dz - mag hz' R2/r + Gr theta - Gf phi
        hzr = np.gradient(hz, r, edge_order=2)
        body = -mag * hzr * (R / r) + p.Gr * theta - p.Gf * phi
        w0 = solve_momentum(r, mu, body, 1.0, p)          # dp/dz = 0, full BC
        w1 = solve_momentum(r, mu, one, 0.0, p)           # dp/dz = 1, homog. BC
        G = (p.q - flow_rate(r, w0)) / flow_rate(r, w1)
        w_new = w0 + G * w1
        w = (1 - p.relax) * w + p.relax * w_new

        # ---- energy (3.10):  -(r theta')' = r [Nb phi'theta' + Nt theta'^2
        #                                         + Ec Pr mu w'^2 + Q]
        wr = np.gradient(w, r, edge_order=2)
        thr = np.gradient(theta, r, edge_order=2)
        phr = np.gradient(phi, r, edge_order=2)
        src = p.Nb * phr * thr + p.Nt * thr**2 + p.Ec * p.Pr * mu * wr**2 + p.Q
        th_new = solve_dirichlet(r, one, zero, src, 0.0, 1.0)
        theta = (1 - p.relax) * theta + p.relax * th_new

        # ---- concentration (3.11):
        #   -(r phi')' + gamma r phi = (Nt/Nb) (r theta')' + S0 r
        lo, md, up = diffusion_rows(r, one)
        lap_th = np.zeros(p.N)                       # (1/r)(r theta')' per cell
        lap_th[1:-1] = -(lo[:-1] * theta[:-2] + md[1:-1] * theta[1:-1]
                         + up[1:] * theta[2:]) / (r[1:-1] * (r[1] - r[0]))
        ph_new = solve_dirichlet(r, one, p.gamma * one,
                                 (p.Nt / p.Nb) * lap_th + p.S0, 0.0, 1.0)
        phi = (1 - p.relax) * phi + p.relax * ph_new

        # ---- induced field (3.12):  -(r hz')' = Rm R2 w'
        hz_new = solve_dirichlet(r, one, zero, p.Rm * (R / r) * wr, 0.0, 0.0)
        hz = (1 - p.relax) * hz + p.relax * hz_new

        res = max(np.max(np.abs(w - w_old)), np.max(np.abs(theta - th_old)),
                  np.max(np.abs(phi - ph_old)), np.max(np.abs(hz - hz_old)))
        if not np.isfinite(res):
            raise RuntimeError(f"Picard iteration diverged at z = {z}")
        if res < p.tol:
            break

    out = dict(r=r, w=w, theta=theta, phi=phi, hz=hz,
               mu=viscosity(np.gradient(w, r, edge_order=2), theta, phi, p),
               dpdz=G, R2=R)
    if return_info:
        out.update(iterations=it + 1, residual=res,
                   q=flow_rate(r, w))
    return out


def solve_channel(p, nz=41):
    """Every field over one wave period 0 <= z <= 1.

    Returns z (nz,), and 2-D arrays (N, nz) R (radius), W, T, PHI, HZ,
    plus dpdz (nz,).
    """
    zs = np.linspace(0.0, 1.0, nz)
    F = {k: np.zeros((p.N, nz)) for k in ("R", "W", "T", "PHI", "HZ")}
    F["dpdz"] = np.zeros(nz)
    for j, z in enumerate(zs):
        s = solve_station(z, p)
        F["R"][:, j] = s["r"]; F["W"][:, j] = s["w"]; F["T"][:, j] = s["theta"]
        F["PHI"][:, j] = s["phi"]; F["HZ"][:, j] = s["hz"]
        F["dpdz"][j] = s["dpdz"]
    return zs, F


# ============================================================ quick check
if __name__ == "__main__":
    p = Params()
    print("Mid-period station z = 0.5, baseline parameters, N =", p.N)
    for m, name in [(1, "Model I  (Carreau-Yasuda)"),
                    (2, "Model II (benchmark)"),
                    (3, "Model III (benchmark)")]:
        p.model = m
        s = solve_station(0.5, p, return_info=True)
        print(f"  {name:28s} dp/dz = {s['dpdz']:+.5f}   "
              f"q = {s['q']:.10f}   w_max = {s['w'].max():.4f}   "
              f"theta_max = {s['theta'].max():.4f}   "
              f"Picard: {s['iterations']} sweeps, residual {s['residual']:.1e}")
