"""
asej2026_hyperthermia.py
========================

Python code accompanying

    M. Saqib, A. Siddique, S. Hasnain, M. Hafez, M. Farman, E. Hincal,
    "A coupled transport model for magnetic hyperthermia in brain tumor
    therapy: Numerical investigation and analysis",
    Ain Shams Engineering Journal 17(12) (2026) 104507.
    https://doi.org/10.1016/j.asej.2026.104507

Model (cylindrical coordinates r, w; Eq. (9) of the article)
------------------------------------------------------------
    d(xi)/dt  = Dc (xi_rr + xi_r / r) - v xi_w - k0 exp(-E/(R eta)) xi^2
    d(eta)/dt = Dt (eta_rr + eta_r / r) - v eta_w
                + H/(rho Cp) k0 exp(-E/(R eta)) xi^2

    xi  : nanoparticle concentration  [mg/mL]
    eta : tissue temperature           [K]

    r = 0     : symmetry,  xi_r = eta_r = 0
    r = Rt    : zero particle flux, convective cooling  -k eta_r = h (eta - Tw)
    w = 0     : infusion,  xi = xi_e,  eta = eta_e
    t = 0     : xi = xi_0, eta = eta_0

Numerical method
----------------
Method of lines. Radial derivatives by the five-point fourth-order
formulae dss004 / dss044 (Schiesser), centreline singularity by
L'Hopital's rule, axial convection by first-order upwinding, and the
resulting ODE system integrated with a stiff BDF solver.

What this script produces
-------------------------
    fig06_effect_of_H.png        Figure 6 of the article
    fig12_centreline_six.png     Figure 12 of the article
    extra_temperature_map.png    additional contour, NOT in the article

Run:   python asej2026_hyperthermia.py      (about 4-5 minutes on a laptop)
Needs: numpy, scipy, matplotlib   (tested with matplotlib 3.11)

Contact: Shahid Hasnain, shahid.hasnain@uoc.edu.pk
         https://shahid-hasnain.github.io
"""

from dataclasses import dataclass, field, replace

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


# =========================================================================
# 1. Parameters (Table 1 of the article; base operating point H = 5 W/g)
# =========================================================================
@dataclass
class Params:
    Rt: float = 2.0         # tumour radius                   cm
    wl: float = 4.0         # treatment length                cm
    nr: int = 13            # radial grid points
    nw: int = 40            # axial grid points

    v: float = 0.1          # convection velocity             cm/s
    Dc: float = 0.01        # mass diffusivity                cm^2/s
    Dt: float = 1.32e-3     # thermal diffusivity             cm^2/s
    k: float = 0.005        # thermal conductivity            W/(cm K)
    h: float = 0.01         # heat transfer coefficient       W/(cm^2 K)
    rho: float = 1.05       # tissue density                  g/cm^3
    Cp: float = 3.6         # specific heat                   J/(g K)

    k0: float = 1.0e6       # pre-exponential factor          mL/(mg s)
    E: float = 5.0e4        # activation energy               J/mol
    R: float = 8.314        # gas constant                    J/(mol K)
    H: float = 5.0          # SAR parameter                   W/g

    xi0: float = 0.0        # initial concentration           mg/mL
    xie: float = 10.0       # infusion concentration          mg/mL
    eta0: float = 310.0     # initial temperature             K
    etae: float = 310.0     # infusion temperature            K
    Tw: float = 310.0       # body temperature                K

    tf: float = 200.0       # final time                      s
    rtol: float = 1.0e-6
    atol: float = 1.0e-8

    r: np.ndarray = field(init=False, repr=False)
    w: np.ndarray = field(init=False, repr=False)

    def __post_init__(self):
        self.dr = self.Rt / (self.nr - 1)
        self.r = np.arange(self.nr) * self.dr
        self.dw = self.wl / self.nw
        self.w = (np.arange(self.nw) + 1) * self.dw   # inlet w = 0 is a boundary value

    def with_(self, **kw):
        return replace(self, **kw)


# =========================================================================
# 2. Fourth-order radial differentiation (dss004, dss044)
# =========================================================================
def dss004(xl, xu, n, u):
    """First derivative along the last axis, five-point, O(dx^4)."""
    dx = (xu - xl) / (n - 1)
    c = 1.0 / (12.0 * dx)
    ux = np.empty_like(u)
    ux[:, 0] = c * (-25*u[:, 0] + 48*u[:, 1] - 36*u[:, 2] + 16*u[:, 3] - 3*u[:, 4])
    ux[:, 1] = c * (-3*u[:, 0] - 10*u[:, 1] + 18*u[:, 2] - 6*u[:, 3] + u[:, 4])
    ux[:, 2:n-2] = c * (u[:, 0:n-4] - 8*u[:, 1:n-3] + 8*u[:, 3:n-1] - u[:, 4:n])
    ux[:, n-2] = c * (-u[:, n-5] + 6*u[:, n-4] - 18*u[:, n-3] + 10*u[:, n-2] + 3*u[:, n-1])
    ux[:, n-1] = c * (3*u[:, n-5] - 16*u[:, n-4] + 36*u[:, n-3] - 48*u[:, n-2] + 25*u[:, n-1])
    return ux


def dss044(xl, xu, n, u, ux):
    """Second derivative along the last axis, O(dx^4), Neumann data at both ends."""
    dx = (xu - xl) / (n - 1)
    c = 1.0 / (12.0 * dx**2)
    uxx = np.empty_like(u)
    uxx[:, 0] = c * (-415/6*u[:, 0] + 96*u[:, 1] - 36*u[:, 2] + 32/3*u[:, 3]
                     - 1.5*u[:, 4] - 50*ux[:, 0]*dx)
    uxx[:, n-1] = c * (-415/6*u[:, n-1] + 96*u[:, n-2] - 36*u[:, n-3] + 32/3*u[:, n-4]
                       - 1.5*u[:, n-5] + 50*ux[:, n-1]*dx)
    uxx[:, 1] = c * (10*u[:, 0] - 15*u[:, 1] - 4*u[:, 2] + 14*u[:, 3] - 6*u[:, 4] + u[:, 5])
    uxx[:, n-2] = c * (10*u[:, n-1] - 15*u[:, n-2] - 4*u[:, n-3] + 14*u[:, n-4]
                       - 6*u[:, n-5] + u[:, n-6])
    uxx[:, 2:n-2] = c * (-u[:, 0:n-4] + 16*u[:, 1:n-3] - 30*u[:, 2:n-2]
                         + 16*u[:, 3:n-1] - u[:, 4:n])
    return uxx


# =========================================================================
# 3. Method-of-lines right-hand side and solver
# =========================================================================
def rhs(t, y, p):
    n = p.nw * p.nr
    xi = y[:n].reshape(p.nw, p.nr)
    eta = y[n:].reshape(p.nw, p.nr)

    # radial first derivatives, then the boundary values
    xi_r = dss004(0.0, p.Rt, p.nr, xi)
    eta_r = dss004(0.0, p.Rt, p.nr, eta)
    xi_r[:, 0] = xi_r[:, -1] = 0.0                    # symmetry, zero flux
    eta_r[:, 0] = 0.0                                 # symmetry
    eta_r[:, -1] = (p.h / p.k) * (p.Tw - eta[:, -1])  # convective cooling

    xi_rr = dss044(0.0, p.Rt, p.nr, xi, xi_r)
    eta_rr = dss044(0.0, p.Rt, p.nr, eta, eta_r)

    # (1/r) d/dr, with u_rr + u_r/r -> 2 u_rr on the axis (L'Hopital)
    xi_lap = xi_rr.copy()
    eta_lap = eta_rr.copy()
    xi_lap[:, 1:] += xi_r[:, 1:] / p.r[1:]
    eta_lap[:, 1:] += eta_r[:, 1:] / p.r[1:]
    xi_lap[:, 0] *= 2.0
    eta_lap[:, 0] *= 2.0

    # first-order upwind in w, inlet values supplied at w = 0
    def d_w(u, u_in):
        du = np.empty_like(u)
        du[0] = (u[0] - u_in) / p.dw
        du[1:] = (u[1:] - u[:-1]) / p.dw
        return du

    react = p.k0 * np.exp(-p.E / (p.R * np.maximum(eta, 1.0))) * xi**2

    dxi = p.Dc * xi_lap - p.v * d_w(xi, p.xie) - react
    deta = p.Dt * eta_lap - p.v * d_w(eta, p.etae) + p.H / (p.rho * p.Cp) * react
    return np.concatenate([dxi.ravel(), deta.ravel()])


def solve(p, t_eval=None):
    """Return t, xi[t, w, r], eta[t, w, r]."""
    if t_eval is None:
        t_eval = np.linspace(0.0, p.tf, 9)
    n = p.nw * p.nr
    y0 = np.concatenate([np.full(n, p.xi0), np.full(n, p.eta0)])
    s = solve_ivp(rhs, (0.0, p.tf), y0, method="BDF", t_eval=t_eval,
                  args=(p,), rtol=p.rtol, atol=p.atol, max_step=p.tf / 20)
    nt = s.y.shape[1]
    xi = s.y[:n].T.reshape(nt, p.nw, p.nr)
    eta = s.y[n:].T.reshape(nt, p.nw, p.nr)
    return s.t, xi, eta


# =========================================================================
# 4. Figure style (common to all article codes on the website)
# =========================================================================
plt.rcParams.update({
    "font.family": "serif", "mathtext.fontset": "dejavuserif",
    "font.size": 12, "axes.labelsize": 13, "axes.linewidth": 1.2,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.top": True, "ytick.right": True,
    "legend.fontsize": 9.5, "legend.frameon": False,
    "axes.grid": False, "savefig.dpi": 300, "savefig.bbox": "tight",
})
LW, MS, MEW = 2.6, 7.0, 2.0      # thick lines, open circles sized to the line


def line_colours(n):
    """PuBuGn, skipping the pale end so every curve stays visible."""
    return [plt.get_cmap("PuBuGn")(x) for x in np.linspace(0.40, 1.0, n)]


def curve(ax, x, y, c, label, every=None):
    ax.plot(x, y, "-", color=c, lw=LW, marker="o", ms=MS, mfc="white",
            mec=c, mew=MEW, markevery=every, label=label)


def panel_label(ax, tag):
    """(a), (b), ... centred above the top border of the panel."""
    ax.set_title(tag, fontsize=13, fontweight="bold", pad=8)


# =========================================================================
# 5. Figure 6 of the article: effect of the heating parameter H
# =========================================================================
def figure_6(base):
    H_values = [2.5, 5.0, 7.5, 10.0, 15.0]
    cols = line_colours(len(H_values))
    fig, ax = plt.subplots(2, 2, figsize=(11.0, 8.4))
    every = max(1, base.nw // 8)

    print("\n  Figure 6: effect of H (outlet values at t = 200 s)")
    for H, c in zip(H_values, cols):
        p = base.with_(H=H)
        _, xi, eta = solve(p)
        lab = rf"$H = {H:g}$"
        curve(ax[0, 0], p.w, xi[-1, :, 0], c, lab, every)
        curve(ax[0, 1], p.w, eta[-1, :, 0], c, lab, every)
        curve(ax[1, 0], p.r, xi[-1, -1, :], c, lab)
        curve(ax[1, 1], p.r, eta[-1, -1, :], c, lab)
        print(f"    H = {H:5.1f} W/g   xi = {xi[-1, -1, 0]:6.3f} mg/mL   "
              f"eta = {eta[-1, -1, 0]:7.2f} K   peak = {eta[-1].max() - 273.15:6.2f} C")

    ax[0, 0].set(xlabel=r"$w$ [cm]", ylabel=r"$\xi(r=0,w)$ [mg mL$^{-1}$]", xlim=(0, base.wl))
    ax[0, 1].set(xlabel=r"$w$ [cm]", ylabel=r"$\eta_k(r=0,w)$ [K]", xlim=(0, base.wl))
    ax[1, 0].set(xlabel=r"$r$ [cm]", ylabel=r"$\xi(r,w=w_l)$ [mg mL$^{-1}$]", xlim=(0, base.Rt))
    ax[1, 1].set(xlabel=r"$r$ [cm]", ylabel=r"$\eta_k(r,w=w_l)$ [K]", xlim=(0, base.Rt))
    for a, tag in zip(ax.ravel(), "abcd"):
        panel_label(a, f"({tag})")
    handles, labels = ax[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=5, fontsize=11,
               title=r"$H$ [W g$^{-1}$]", title_fontsize=11,
               bbox_to_anchor=(0.5, 1.06))
    fig.tight_layout()
    fig.savefig("fig06_effect_of_H.png")
    plt.close(fig)


# =========================================================================
# 6. Figure 12 of the article: centreline temperature, six parameters
# =========================================================================
STUDIES = [
    ("k0", [0.5e6, 1.0e6, 1.5e6, 2.0e6, 2.5e6], r"$k_0$", r"mL mg$^{-1}$ s$^{-1}$"),
    ("Dc", [0.0025, 0.005, 0.01, 0.02, 0.04], r"$D_c$", r"cm$^2$ s$^{-1}$"),
    ("Dt", [5.0e-4, 1.0e-3, 1.32e-3, 2.0e-3, 5.0e-3], r"$D_t$", r"cm$^2$ s$^{-1}$"),
    ("v", [0.05, 0.10, 0.25, 0.50, 1.00], r"$v$", r"cm s$^{-1}$"),
    ("E", [3.0e4, 4.0e4, 5.0e4, 6.0e4, 7.0e4], r"$E$", r"J mol$^{-1}$"),
    ("H", [2.5, 5.0, 7.5, 10.0, 15.0], r"$H$", r"W g$^{-1}$"),
]


def figure_12(base):
    fig, ax = plt.subplots(2, 3, figsize=(15.5, 8.8))
    every = max(1, base.nw // 8)
    print("\n  Figure 12: centreline outlet temperature (C) at t = 200 s")
    for a, (name, values, sym, unit), tag in zip(ax.ravel(), STUDIES, "abcdef"):
        cols = line_colours(len(values))
        out = []
        for val, c in zip(values, cols):
            p = base.with_(**{name: float(val)})
            _, _, eta = solve(p)
            T = eta[-1, :, 0] - 273.15
            curve(a, p.w, T, c, f"{val:.3g}", every)
            out.append(T[-1])
        a.set(xlabel=r"$w$ [cm]", ylabel=r"$\eta_k(r=0,w)$ [$^\circ$C]", xlim=(0, base.wl))
        panel_label(a, f"({tag})")
        if name == "E":   # keep the legend clear of the steep low-E curves
            a.legend(loc="lower right", bbox_to_anchor=(1.0, 0.07),
                     title=f"{sym} [{unit}]", title_fontsize=9.5)
        else:
            a.legend(loc="best", title=f"{sym} [{unit}]", title_fontsize=9.5)
        print(f"    {name:>3}: " + "  ".join(f"{T:6.2f}" for T in out))
    fig.tight_layout()
    fig.savefig("fig12_centreline_six.png")
    plt.close(fig)


# =========================================================================
# 7. Additional result (not in the article): temperature map eta(r, w)
# =========================================================================
def extra_temperature_map(base):
    p = base.with_(nr=25, nw=80)
    _, _, eta = solve(p)
    T = eta[-1] - 273.15
    # mirror about the axis to show the full cross-section of the tumour
    rr = np.concatenate([-p.r[::-1], p.r[1:]])
    TT = np.concatenate([T[:, ::-1], T[:, 1:]], axis=1)

    fig, ax = plt.subplots(figsize=(8.6, 5.2))
    cf = ax.contourf(p.w, rr, TT.T, levels=40, cmap="coolwarm")
    cs = ax.contour(p.w, rr, TT.T, levels=[42.0], colors="k",
                    linewidths=1.6, linestyles="--")
    ax.clabel(cs, fmt=r"%.0f $^\circ$C", fontsize=10)
    cb = fig.colorbar(cf, ax=ax, pad=0.02)
    cb.set_label(r"$\eta_k$ [$^\circ$C]")
    ax.set(xlabel=r"$w$ [cm]", ylabel=r"$r$ [cm]")
    ax.set_title("Temperature Results", fontsize=13, fontweight="bold", pad=8)
    fig.text(0.5, -0.04,
             "Disclaimer: this figure is an additional illustration produced with the code "
             "and does not appear in the article.\nBase operating point of Table 1 with "
             r"$H = 5$ W g$^{-1}$, $t = 200$ s, on a refined $25 \times 80$ grid.",
             ha="center", va="top", fontsize=9.5, style="italic")
    fig.tight_layout()
    fig.savefig("extra_temperature_map.png")
    plt.close(fig)
    print(f"\n  Extra map: peak {T.max():.2f} C, "
          f"dashed contour marks 42 C")


# =========================================================================
if __name__ == "__main__":
    base = Params()
    t, xi, eta = solve(base)
    print("  Centreline values at t = 200 s (compare Table 5 of the article)")
    print("     w (cm)    xi (mg/mL)    eta (K)")
    for w in (0.5, 1.0, 2.0, 3.0, 4.0):
        i = int(np.argmin(np.abs(base.w - w)))
        print(f"    {base.w[i]:6.2f}    {xi[-1, i, 0]:10.4f}   {eta[-1, i, 0]:9.2f}")

    figure_6(base)
    figure_12(base)
    extra_temperature_map(base)
    print("\n  Done: fig06_effect_of_H.png, fig12_centreline_six.png, "
          "extra_temperature_map.png")
