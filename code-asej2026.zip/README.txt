Code for: M. Saqib, A. Siddique, S. Hasnain, M. Hafez, M. Farman, E. Hincal,
"A coupled transport model for magnetic hyperthermia in brain tumor therapy:
Numerical investigation and analysis", Ain Shams Engineering Journal 17(12)
(2026) 104507. https://doi.org/10.1016/j.asej.2026.104507

Run:    python asej2026_hyperthermia.py
Needs:  Python 3.9+, numpy, scipy, matplotlib
Time:   about 4-5 minutes on a laptop

Output:
  fig06_effect_of_H.png       reproduces Figure 6 of the article
  fig12_centreline_six.png    reproduces Figure 12 of the article
  extra_temperature_map.png   additional result, not in the article

The printed centreline values reproduce Table 5 of the article.
Questions and corrections are welcome: shahid.hasnain@uoc.edu.pk
