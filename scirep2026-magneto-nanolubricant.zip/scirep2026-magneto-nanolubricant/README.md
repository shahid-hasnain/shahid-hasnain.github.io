# Magneto-nanolubricant peristaltic flow solver

Companion code for

> S. Hasnain, N. O. Al-Atawi, M. Saqib, *Numerical study of magneto-nanolubricant
> transport through a porous wavy channel using three non-Newtonian rheological
> models*, **Scientific Reports** (2026).
> https://doi.org/10.1038/s41598-026-71090-4

A finite-volume solver for peristaltic flow of synovial fluid between the wavy
membrane and the cartilage of the knee. It computes the velocity, temperature,
nanoparticle concentration, induced magnetic field and a FitzHugh–Nagumo-type
neural-activation field, with three non-Newtonian viscosity models
(Model I exponential, Model II concentration index, Model III Carreau–Yasuda).

## Files

| File | What it does |
|---|---|
| `solver.py` | The full solver: governing equations, boundary conditions, closures. Run it for a quick check of the baseline case. |
| `bolus_results.py` | Draws the **Bolus Results** figure (trapped bolus for the three models). |

## How to run

```
pip install -r requirements.txt
python solver.py            # baseline check, about 20 s
python bolus_results.py     # Bolus Results figure, about 35 s
python bolus_results.py --sweeps   # also the Nt and Da sweep figures
```

Use `--nx 65 --ny 121` for a finer grid.

## What the solver does, step by step

1. At each axial station `x`, the momentum, energy, concentration and
   induced-field equations are solved across the gap by a damped Picard
   iteration. Each linear system is tridiagonal and is solved by the Thomas
   algorithm.
2. `dp/dx` at each station is found by a secant iteration so that the flux
   `∫ u dy` equals `Q`.
3. `Q` is either prescribed or found from free pumping: the net pressure rise
   over one wavelength is zero (secant iteration on `Q`).
4. The concentration uses the Scharfetter–Gummel scheme, which keeps the
   concentration positive on every grid.

Expected output of `python solver.py` (Model III, Nx = 25, Ny = 51):
free-pumping `Q ≈ -2.786`, net `dp/dx` over one wavelength ≈ 1e-15,
`phi > 0` everywhere.

## Note on the Bolus Results figure

The Bolus Results figure is an **illustrative demonstration** of the solver.
It is **not** a figure from the published article. It uses no-slip walls,
`Da = 5` and a prescribed `Q = 1.5`, the conditions under which a trapped
bolus forms.

## Collaboration

I welcome collaboration on extensions of this model: new rheology, other
joint geometries, time-dependent loading, experimental comparison, or
student projects built on this code. If you use the code, find a problem,
or would like to work together, please write to me:

Shahid Hasnain — shahid.hasnain@uoc.edu.pk · s.hasnain.mathematics@gmail.com

## Licence

MIT (see `LICENSE`). If you use this code, please cite the article above.
