"""
=============================================================================
Bolus Results: trapped bolus in the wave frame for Models I, II and III.

ILLUSTRATIVE DEMONSTRATION - this figure shows what the solver can do.
It is NOT a figure from the published article.

The stream function is psi = int u dy from the lower wall, so psi = 0 on the
lower wall and psi = Q on the upper wall. A streamline is closed (trapped)
exactly when psi lies outside [0, Q]. Only that region is coloured; the
open-flow core is left blank, and closed streamlines are drawn on top.

Usage
    python bolus_results.py                    # default grid  (Nx=33, Ny=61)
    python bolus_results.py --nx 65 --ny 121   # finer grid
    python bolus_results.py --sweeps           # also the Nt and Da figures

Output
    bolus_results.png            (always)
    bolus_contour_Nt.png         (with --sweeps)
    bolus_contour_Da.png         (with --sweeps)

Requires: numpy, matplotlib, and solver.py in the same folder.
=============================================================================
"""

import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

import solver as S

BOLUS_CMAP = LinearSegmentedColormap.from_list(
    "bolus", ["#2b1b64", "#1f6f8b", "#3fa796", "#f0a04b", "#f7e1a0"])
WALL_COLOR = "#16213e"
LINE_COLOR = "#0d2137"
MODELS = [(1, "Model I"), (2, "Model II"), (3, "Model III")]


def bolus_field(p, Q):
    xs, U, Y = S.solve_at_Q(p, Q)
    if not np.isfinite(U).all():
        raise RuntimeError("solver returned NaN: reduce Nt, Q_source, Ec, Da or Q")
    PSI = S.stream_function(U, Y)
    X = np.repeat(xs[None, :], p.Ny, axis=0)
    return X, Y, PSI, float(PSI[-1].mean()), U


def draw_panel(ax, p, Q, title, n_fill=14, n_line=7):
    X, Y, PSI, psi_hi, U = bolus_field(p, Q)
    psi_lo = 0.0
    over = np.maximum(PSI - psi_hi, 0.0) + np.maximum(psi_lo - PSI, 0.0)
    inside = over > 0.0
    frac = inside.sum() / inside.size

    ax.set_facecolor("white")
    if over.max() > 0:
        ax.contourf(X, Y, np.where(inside, over, np.nan),
                    levels=np.linspace(0.0, over.max(), n_fill),
                    cmap=BOLUS_CMAP, alpha=0.92)
        lv_up = np.linspace(psi_hi, PSI.max(), n_line + 1)[1:]
        lv_lo = np.linspace(PSI.min(), psi_lo, n_line + 1)[:-1]
        ax.contour(X, Y, PSI, levels=np.sort(np.concatenate([lv_lo, lv_up])),
                   colors=LINE_COLOR, linewidths=0.6, linestyles="solid")
        ax.text(0.985, 0.03, f"bolus area {100 * frac:.1f}%",
                transform=ax.transAxes, ha="right", va="bottom", fontsize=8,
                color=LINE_COLOR,
                bbox=dict(boxstyle="round,pad=0.25", fc="white",
                          ec="#cccccc", alpha=0.85))
    else:
        ax.text(0.5, 0.5, "no trapped bolus", transform=ax.transAxes,
                ha="center", va="center", fontsize=10, color="#888")

    xf = np.linspace(0, p.lam, 400)
    ax.plot(xf, S.h1(xf, p), color=WALL_COLOR, lw=2.2)
    ax.plot(xf, S.h2(xf, p), color=WALL_COLOR, lw=2.2)
    ax.set_xlim(0, p.lam)
    ax.set_title(title, fontsize=10, pad=5)
    ax.tick_params(labelsize=8)
    return dict(frac=frac, umin=U.min(), umax=U.max(),
                pmin=PSI.min(), pmax=PSI.max(), psi_hi=psi_hi)


def bolus_results(nx, ny, Q, fname="bolus_results.png"):
    """One row: the trapped bolus for the three viscosity models."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), sharey=True)
    print(f"\nBolus Results  (Q = {Q}, Nx = {nx}, Ny = {ny})")
    print(f"{'model':<11}{'u_min':>9}{'u_max':>9}{'psi_min':>10}"
          f"{'psi_max':>10}{'bolus %':>10}")
    for ax, (m, name) in zip(axes, MODELS):
        p = S.trapping_params(nx, ny)
        p.model = m
        r = draw_panel(ax, p, Q, name)
        ax.set_xlabel("$x$")
        print(f"{name:<11}{r['umin']:>9.3f}{r['umax']:>9.3f}"
              f"{r['pmin']:>10.3f}{r['pmax']:>10.3f}{100 * r['frac']:>10.2f}")
    axes[0].set_ylabel("$y$")
    fig.suptitle(f"Bolus Results: trapped bolus in the wave frame "
                 f"(no-slip walls, prescribed $Q = {Q}$)", fontsize=13, y=1.0)
    fig.text(0.5, 0.925, "Illustrative demonstration - not a figure from the "
             "published article", ha="center", fontsize=9, style="italic",
             bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#999"))
    fig.tight_layout(rect=[0, 0, 1, 0.9])
    fig.savefig(fname, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"saved {fname}")


def sweep_figure(nx, ny, Q, attr, values, label, fname):
    """3 x 2 grid: rows = models, columns = two values of one parameter."""
    fig, axes = plt.subplots(3, 2, figsize=(11.5, 11.0), sharex=True)
    for i, (m, name) in enumerate(MODELS):
        for j, val in enumerate(values):
            p = S.trapping_params(nx, ny)
            p.model = m
            setattr(p, attr, val)
            draw_panel(axes[i, j], p, Q, f"{name}   ${label} = {val:g}$")
            if j == 0:
                axes[i, j].set_ylabel("$y$")
            if i == 2:
                axes[i, j].set_xlabel("$x$")
    fig.suptitle(f"Trapped bolus: effect of ${label}$  (prescribed $Q = {Q}$)"
                 "\nIllustrative demonstration - not a figure from the "
                 "published article", fontsize=12, y=0.995)
    fig.tight_layout(rect=[0, 0, 1, 0.975])
    fig.savefig(fname, dpi=145, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"saved {fname}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nx", type=int, default=33)
    ap.add_argument("--ny", type=int, default=61)
    ap.add_argument("--Q", type=float, default=1.5)
    ap.add_argument("--sweeps", action="store_true",
                    help="also draw the Nt and Da sweep figures")
    args = ap.parse_args()

    bolus_results(args.nx, args.ny, args.Q)
    if args.sweeps:
        sweep_figure(args.nx, args.ny, args.Q, "Nt", [0.0, 0.1], "N_t",
                     "bolus_contour_Nt.png")
        sweep_figure(args.nx, args.ny, args.Q, "Da", [0.5, 3.0], "Da",
                     "bolus_contour_Da.png")


if __name__ == "__main__":
    main()
