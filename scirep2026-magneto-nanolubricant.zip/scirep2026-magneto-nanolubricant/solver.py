"""
=============================================================================
Magneto-nanolubricant peristaltic flow solver
Companion code for:
    S. Hasnain, N. O. Al-Atawi, M. Saqib,
    "Numerical study of magneto-nanolubricant transport through a porous
    wavy channel using three non-Newtonian rheological models",
    Scientific Reports (2026). https://doi.org/10.1038/s41598-026-71090-4

Peristaltic flow of synovial fluid between the wavy membrane and the
cartilage of the knee, in the wave frame, long-wavelength and
low-Reynolds-number limit. At each axial station x the following
two-point problems in y are solved, h2(x) <= y <= h1(x):

  Momentum       d/dy( mu u' ) - (1/Da)(u + 1) + S^2 Re (H0 + hx) hx' = dp/dx
  Energy         theta'' + Nb theta' phi' + Nt (theta')^2
                         + Ec Pr mu (u')^2 + Qs = 0
  Concentration  d/dy[ phi' + (Nt/Nb) phi theta' ] = 0
  Induced field  hx'' = -Rm (H0 + hx) u'
  Neural field   N'' + gN N (1-N)(N-a) - (gR/beta) N
                     + g_theta theta + g_phi phi + g_M hx^2 = 0

  Viscosity mu(u', phi, theta):
    Model I    exponential (concentration) with shear thinning
    Model II   concentration-dependent power index
    Model III  Carreau-Yasuda with temperature and concentration dependence

Boundary conditions
  walls (wave frame, wall moves at u = -1):
    Beavers-Joseph slip      lower  u' =  beta2 (u + 1),  beta2 = alpha2/sqrt(Da2)
                             upper  u' = -beta1 (u + 1),  beta1 = alpha1/sqrt(Da1)
    or no-slip (noslip=True) u = -1 on both walls
  temperature   convective (Biot) at both walls
                  lower (bone):      theta' = Bi2 (theta - theta_bone)
                  upper (membrane): -theta' = Bi1 (theta - theta_blood)
  concentration zero flux at the cartilage, phi = phi_injection at the membrane
  induced field hx = 0 at the lower wall, hx' = 0 at the upper wall
  neural field  N = 0 at the lower wall, N' = 0 at the upper wall

Closures
  * dp/dx at each station from the flux constraint  int u dy = Q  (secant);
  * Q either prescribed, or from free pumping: net dp/dx over one wavelength
    equals zero (secant on Q).

Numerics
  Second-order finite-volume discretisation in y with face-averaged
  viscosity, Thomas algorithm for every tridiagonal system, damped Picard
  iteration for the couplings, second-order ghost-point Biot rows, and the
  Scharfetter-Gummel (exponential) scheme for the concentration, which keeps
  phi > 0 for every grid.

Requires: numpy (>= 1.25 for numpy.trapezoid).
Licence: MIT (see LICENSE).

Questions, corrections and collaboration are welcome:
    Shahid Hasnain, shahid.hasnain@uoc.edu.pk, s.hasnain.mathematics@gmail.com
=============================================================================
"""

import numpy as np


# =============================================================== parameters
class Params:
    """All model constants (dimensionless). Defaults = baseline set."""

    def __init__(self):
        # ---- geometry
        self.a = 0.7            # upper wall wave amplitude
        self.b = 0.5            # lower wall wave amplitude
        self.d = 2.0            # mean half-width of the lower side
        self.phi = np.pi / 4    # phase difference between the walls
        self.lam = 2.0          # wavelength

        # ---- porous medium and wall slip
        self.Da = 0.05          # bulk Darcy number
        self.Da1 = 0.1          # upper wall Darcy number
        self.Da2 = 0.3          # lower wall Darcy number
        self.alpha1_slip = 0.1  # upper Beavers-Joseph coefficient
        self.alpha2_slip = 0.0  # lower Beavers-Joseph coefficient
        self.noslip = False     # True: u = -1 on both walls

        # ---- viscosity: 1 = Model I, 2 = Model II, 3 = Model III
        self.model = 3
        self.mu_e = 1.0
        self.mu00 = 1.0
        self.alpha = 0.5
        self.omega_e = 0.3
        self.n = -0.2
        self.a_cy = 2.0
        self.lam0 = 1.0
        self.beta1 = 0.3
        self.beta2 = 0.2
        self.beta3 = 0.1
        self.alpha1_v = 0.1
        self.alpha2_v = 0.1

        # ---- thermal and solutal
        self.Pr = 0.7
        self.Ec = 0.1
        self.Q_source = 1.0
        self.Nb = 0.2
        self.Nt = 0.1
        self.Bi1 = 0.6
        self.Bi2 = 1.0
        self.theta_blood = 1.0
        self.theta_bone = 0.0
        self.phi_injection = 1.0

        # ---- magnetic
        self.S = 0.5
        self.Re = 0.1
        self.H0 = 0.05
        self.Rm = 0.5

        # ---- neural activation
        self.gN = 20.0
        self.gR = 0.5
        self.beta = 0.1
        self.a_N = 0.03
        self.gth = 0.3
        self.gph = 0.3
        self.gM = 0.5

        # ---- grid
        self.Nx = 33            # axial stations over one wavelength
        self.Ny = 61            # points across the gap


def baseline_params(nx=33, ny=61):
    """Parameter set of the velocity and temperature results."""
    p = Params()
    p.Nx, p.Ny = nx, ny
    return p


def trapping_params(nx=33, ny=61):
    """Parameter set in which a trapped bolus forms.

    A closed streamline needs u to change sign across the gap:
      * no-slip walls pin u = -1 at the wall (negative near-wall flow);
      * a larger Darcy number thickens the Brinkman layer, sqrt(Da mu),
        so the bolus can fill the gap;
      * a positive prescribed Q makes the core velocity positive.
    Nt, Q_source and Ec are reduced to keep the Picard sweeps convergent.
    """
    p = Params()
    p.Nx, p.Ny = nx, ny
    p.noslip = True
    p.Da = 5.0
    p.d = 1.0
    p.Nt = 0.05
    p.Q_source = 0.5
    p.Ec = 0.05
    return p


# ================================================================= geometry
def h1(x, p):
    """Upper wall (membrane)."""
    return 1.0 + p.a * np.cos(2 * np.pi * x / p.lam)


def h2(x, p):
    """Lower wall (cartilage)."""
    return -p.d - p.b * np.cos(2 * np.pi * x / p.lam + p.phi)


# =========================================================== linear algebra
def thomas(a, b, c, d):
    """Tridiagonal solve: a = sub-diagonal, b = diagonal, c = super, d = rhs."""
    n = len(d)
    b = b.copy()
    d = d.copy()
    for i in range(1, n):
        m = a[i] / b[i - 1]
        b[i] -= m * c[i - 1]
        d[i] -= m * d[i - 1]
    x = np.zeros(n)
    x[-1] = d[-1] / b[-1]
    for i in range(n - 2, -1, -1):
        x[i] = (d[i] - c[i] * x[i + 1]) / b[i]
    return x


def bernoulli(x):
    """B(x) = x / (exp(x) - 1), with B(0) = 1."""
    x = np.asarray(x, float)
    out = np.ones_like(x)
    m = np.abs(x) > 1e-12
    out[m] = x[m] / (np.exp(x[m]) - 1.0)
    return out


# ================================================================== physics
def viscosity(uy, phi, theta, p):
    """mu(|u'|, phi, theta) for Models I, II and III."""
    D = np.abs(uy)
    if p.model == 1:
        return p.mu_e * np.exp(p.alpha * phi) * (1 + p.omega_e**2 * D**2) ** p.n
    if p.model == 2:
        nphi = 0.5 * (1 - np.exp(-p.alpha * phi))
        return p.mu_e * (1 + p.omega_e**2 * D**2) ** nphi
    mu0 = p.mu00 * (1 + p.alpha1_v * phi) * np.exp(-p.beta1 * theta)
    muinf = p.mu_e * np.exp(-p.beta2 * theta)
    nT = p.n * (1 + p.alpha2_v * phi) * np.exp(-p.beta3 * theta)
    mu = muinf + (mu0 - muinf) * (1 + p.lam0 * D**p.a_cy) ** ((nT - 1) / p.a_cy)
    return np.maximum(mu, 1e-4)


def solve_momentum(y, dpdx, mu, hx, p):
    """d/dy(mu u') - (1/Da)(u+1) + S^2 Re (H0+hx) hx' = dp/dx."""
    Ny = len(y)
    h = y[1] - y[0]
    muf = 0.5 * (mu[:-1] + mu[1:])                       # face viscosities
    lor = p.S**2 * p.Re * (p.H0 + hx) * np.gradient(hx, y)

    a = np.zeros(Ny); b = np.zeros(Ny); c = np.zeros(Ny); d = np.zeros(Ny)
    for i in range(1, Ny - 1):
        a[i] = muf[i - 1] / h**2
        c[i] = muf[i] / h**2
        b[i] = -(muf[i - 1] + muf[i]) / h**2 - 1.0 / p.Da
        d[i] = dpdx + 1.0 / p.Da - lor[i]

    if p.noslip:
        b[0] = 1.0;  c[0] = 0.0;  d[0] = -1.0
        a[-1] = 0.0; b[-1] = 1.0; d[-1] = -1.0
    else:
        # lower: (u1-u0)/h = beta2 (u0 + 1)
        b2 = p.alpha2_slip / np.sqrt(p.Da2)
        b[0] = -(1.0 / h) - b2; c[0] = 1.0 / h; d[0] = b2
        # upper: (uN-uN-1)/h = -beta1 (uN + 1)
        b1 = p.alpha1_slip / np.sqrt(p.Da1)
        a[-1] = -1.0 / h; b[-1] = 1.0 / h + b1; d[-1] = -b1
    return thomas(a, b, c, d)


def solve_energy(y, u, phi, mu, p, sweeps=12):
    """theta'' + Nb theta' phi' + Nt theta'^2 + Ec Pr mu u'^2 + Qs = 0."""
    Ny = len(y)
    h = y[1] - y[0]
    diss = p.Ec * p.Pr * mu * np.gradient(u, y) ** 2
    theta = np.linspace(p.theta_bone, p.theta_blood, Ny)
    for _ in range(sweeps):
        dth = np.gradient(theta, y)
        dph = np.gradient(phi, y)
        src = p.Nb * dth * dph + p.Nt * dth**2 + diss + p.Q_source
        a = np.zeros(Ny); b = np.zeros(Ny); c = np.zeros(Ny); d = np.zeros(Ny)
        for i in range(1, Ny - 1):
            a[i] = 1 / h**2; c[i] = 1 / h**2
            b[i] = -2 / h**2; d[i] = -src[i]
        # second-order ghost-point Biot rows
        b[0] = -2 * (1 + h * p.Bi2) / h**2; c[0] = 2 / h**2
        d[0] = -src[0] - 2 * p.Bi2 * p.theta_bone / h
        a[-1] = 2 / h**2; b[-1] = -2 * (1 + h * p.Bi1) / h**2
        d[-1] = -src[-1] - 2 * p.Bi1 * p.theta_blood / h
        new = 0.5 * thomas(a, b, c, d) + 0.5 * theta    # damped Picard
        if np.max(np.abs(new - theta)) < 1e-9:
            return new
        theta = new
    return theta


def solve_conc(y, theta, p):
    """d/dy[phi' + (Nt/Nb) phi theta'] = 0, Scharfetter-Gummel: phi > 0."""
    Ny = len(y)
    h = y[1] - y[0]
    ds = np.diff((p.Nt / p.Nb) * theta)
    Bp = bernoulli(ds)
    Bm = bernoulli(-ds)
    a = np.zeros(Ny); b = np.zeros(Ny); c = np.zeros(Ny); d = np.zeros(Ny)
    for i in range(1, Ny - 1):
        a[i] = Bp[i - 1] / h
        c[i] = Bm[i] / h
        b[i] = -(Bp[i] + Bm[i - 1]) / h
    b[0] = -Bp[0]; c[0] = Bm[0]; d[0] = 0.0             # zero flux, cartilage
    a[-1] = 0.0; b[-1] = 1.0; d[-1] = p.phi_injection   # membrane
    return thomas(a, b, c, d)


def solve_induced(y, u, p, sweeps=8):
    """hx'' = -Rm (H0 + hx) u',  hx(lower) = 0,  hx'(upper) = 0."""
    Ny = len(y)
    h = y[1] - y[0]
    du = np.gradient(u, y)
    hx = np.zeros(Ny)
    for _ in range(sweeps):
        a = np.zeros(Ny); b = np.zeros(Ny); c = np.zeros(Ny); d = np.zeros(Ny)
        for i in range(1, Ny - 1):
            a[i] = 1 / h**2; c[i] = 1 / h**2; b[i] = -2 / h**2
            d[i] = -p.Rm * (p.H0 + hx[i]) * du[i]
        b[0] = 1.0; c[0] = 0.0; d[0] = 0.0
        a[-1] = 2 / h**2; b[-1] = -2 / h**2
        d[-1] = -p.Rm * (p.H0 + hx[-1]) * du[-1]
        new = thomas(a, b, c, d)
        if np.max(np.abs(new - hx)) < 1e-12:
            return new
        hx = 0.7 * new + 0.3 * hx
    return hx


def solve_neural(y, theta, phi, hx, p, sweeps=60):
    """N'' + gN N(1-N)(N-a) - (gR/beta) N + gth theta + gph phi + gM hx^2 = 0."""
    Ny = len(y)
    h = y[1] - y[0]
    N = np.linspace(0.0, 0.3, Ny)
    src = p.gth * theta + p.gph * phi + p.gM * hx**2
    for _ in range(sweeps):
        a = np.zeros(Ny); b = np.zeros(Ny); c = np.zeros(Ny); d = np.zeros(Ny)
        for i in range(1, Ny - 1):
            a[i] = 1 / h**2; c[i] = 1 / h**2
            b[i] = -2 / h**2 + p.gN * (1 - N[i]) * (N[i] - p.a_N) - p.gR / p.beta
            d[i] = -src[i]
        b[0] = 1.0; c[0] = 0.0; d[0] = 0.0               # N = 0, lower
        a[-1] = 2 / h**2; b[-1] = -2 / h**2; d[-1] = 0.0  # N' = 0, upper
        new = thomas(a, b, c, d)
        if np.max(np.abs(new - N)) < 1e-9:
            return new
        N = 0.5 * new + 0.5 * N
    return N


def station_fields(y, dpdx, p, sweeps=12, neural=False):
    """Coupled sweep at one station. Returns u, theta, phi, hx (and N)."""
    Ny = len(y)
    u = np.full(Ny, -1.0)
    theta = np.linspace(p.theta_bone, p.theta_blood, Ny)
    phi = np.full(Ny, p.phi_injection)
    hx = np.zeros(Ny)
    for _ in range(sweeps):
        mu = viscosity(np.gradient(u, y), phi, theta, p)
        un = solve_momentum(y, dpdx, mu, hx, p)
        u = 0.5 * un + 0.5 * u
        theta = solve_energy(y, u, phi, mu, p)
        phi = solve_conc(y, theta, p)
        hx = solve_induced(y, u, p)
        if np.max(np.abs(un - u)) < 1e-7:
            break
    if neural:
        return u, theta, phi, hx, solve_neural(y, theta, phi, hx, p)
    return u, theta, phi, hx


# ================================================================= closures
def flow_rate(x, dpdx, p):
    y = np.linspace(h2(x, p), h1(x, p), p.Ny)
    u, *_ = station_fields(y, dpdx, p)
    return np.trapezoid(u, y)


def dpdx_for_Q(x, Q, p, iters=12):
    """Secant on dp/dx so that the station flux equals Q."""
    g0, g1 = -1.0, 1.0
    f0 = flow_rate(x, g0, p) - Q
    f1 = flow_rate(x, g1, p) - Q
    for _ in range(iters):
        if abs(f1 - f0) < 1e-12:
            break
        g2 = g1 - f1 * (g1 - g0) / (f1 - f0)
        g0, f0 = g1, f1
        g1 = g2
        f1 = flow_rate(x, g1, p) - Q
        if abs(f1) < 1e-10:
            break
    return g1


def free_pumping_Q(p, iters=10):
    """Secant on Q so that the net pressure rise over one wavelength is zero."""
    xs = np.linspace(0, p.lam, p.Nx)
    net = lambda Q: np.trapezoid([dpdx_for_Q(x, Q, p) for x in xs], xs)
    Q0, Q1 = -0.5, 0.5
    f0, f1 = net(Q0), net(Q1)
    for _ in range(iters):
        if abs(f1 - f0) < 1e-12:
            break
        Q2 = Q1 - f1 * (Q1 - Q0) / (f1 - f0)
        Q0, f0 = Q1, f1
        Q1 = Q2
        f1 = net(Q1)
        if abs(f1) < 1e-9:
            break
    return Q1


def solve_at_Q(p, Q):
    """u(x, y) and y(x) over one wavelength at prescribed flux Q."""
    xs = np.linspace(0, p.lam, p.Nx)
    U = np.zeros((p.Ny, p.Nx))
    Y = np.zeros((p.Ny, p.Nx))
    for j, x in enumerate(xs):
        g = dpdx_for_Q(x, Q, p)
        y = np.linspace(h2(x, p), h1(x, p), p.Ny)
        u, *_ = station_fields(y, g, p)
        U[:, j] = u
        Y[:, j] = y
    return xs, U, Y


def solve_all_fields(p, Q=None):
    """Every field over one wavelength. Q=None -> free pumping.

    Returns xs, F, Q with F keys U, T (theta), P (phi), H (hx), N, Y, dpdx.
    """
    if Q is None:
        Q = free_pumping_Q(p)
    xs = np.linspace(0, p.lam, p.Nx)
    F = {k: np.zeros((p.Ny, p.Nx)) for k in ("U", "T", "P", "H", "N", "Y")}
    F["dpdx"] = np.zeros(p.Nx)
    for j, x in enumerate(xs):
        g = dpdx_for_Q(x, Q, p)
        y = np.linspace(h2(x, p), h1(x, p), p.Ny)
        u, th, ph, hx, N = station_fields(y, g, p, neural=True)
        F["U"][:, j] = u; F["T"][:, j] = th; F["P"][:, j] = ph
        F["H"][:, j] = hx; F["N"][:, j] = N; F["Y"][:, j] = y
        F["dpdx"][j] = g
    return xs, F, Q


def stream_function(U, Y):
    """psi = int u dy from the lower wall (psi = 0 there)."""
    PSI = np.zeros_like(U)
    for j in range(U.shape[1]):
        PSI[1:, j] = np.cumsum(0.5 * (U[1:, j] + U[:-1, j]) * np.diff(Y[:, j]))
    return PSI


# ============================================================ quick check
if __name__ == "__main__":
    import time
    p = baseline_params(nx=25, ny=51)
    t0 = time.time()
    xs, F, Q = solve_all_fields(p)
    print(f"Baseline, Model {p.model}, Nx={p.Nx}, Ny={p.Ny}  "
          f"({time.time() - t0:.0f} s)")
    print(f"  free-pumping Q        = {Q:.5f}")
    print(f"  net dp/dx over lambda = {np.trapezoid(F['dpdx'], xs):.2e}")
    print(f"  u     in [{F['U'].min():.4f}, {F['U'].max():.4f}]")
    print(f"  theta in [{F['T'].min():.4f}, {F['T'].max():.4f}]")
    print(f"  phi   in [{F['P'].min():.4f}, {F['P'].max():.4f}]  "
          f"(phi > 0: {(F['P'] > 0).all()})")
    print(f"  hx    in [{F['H'].min():.3e}, {F['H'].max():.3e}]")
    print(f"  N     in [{F['N'].min():.4f}, {F['N'].max():.4f}]")
